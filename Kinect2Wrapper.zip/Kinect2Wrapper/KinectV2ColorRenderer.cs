﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class KinectV2ColorRenderer: MonoBehaviour
{

    private const int IM_W = 1920;
    private const int IM_H = 1080;
    private byte[] seqTex;
    private Color32[] cols;
    Texture2D tex;


    // Use this for initialization
    void Start()
    {
        Kinect_Init();

        seqTex = new byte[IM_W * IM_H * 4];
        cols = new Color32[IM_W * IM_H];
        tex = new Texture2D(IM_W, IM_H, TextureFormat.ARGB32, false);
        renderer.material.mainTexture = tex;

    }

    // Update is called once per frame
    void Update()
    {
        Poll_Color();
        SetCurrentTexture();
    }

    private void OnApplicationQuit()
    {
        Kinect_Deinit();
    }

    private void SetCurrentTexture()
    {

        int size = 0;
        IntPtr ptr = Get_Color(ref size);

        if (ptr != IntPtr.Zero)
        {
            Marshal.Copy(ptr, seqTex, 0, size);
        }

        for (int i = 0; i < (IM_W * IM_H * 4); i +=4 )
        {
            cols[(IM_W * IM_H) - (i / 4) - 1] = new Color32(seqTex[i + 2], seqTex[i + 1], seqTex[i], 255);
        }
        tex.SetPixels32(cols);
        tex.Apply(false);
    }

    [DllImport("/Assets/Plugins/Kinect2Wrapper.dll")]
    public static extern bool Kinect_Init();

    [DllImport("/Assets/Plugins/Kinect2Wrapper.dll")]
    public static extern bool Kinect_Deinit();

    [DllImport("/Assets/Plugins/Kinect2Wrapper.dll")]
    public static extern bool Poll_Color();

    [DllImport("/Assets/Plugins/Kinect2Wrapper.dll")]
    public static extern IntPtr Get_Color(ref int size);
}
